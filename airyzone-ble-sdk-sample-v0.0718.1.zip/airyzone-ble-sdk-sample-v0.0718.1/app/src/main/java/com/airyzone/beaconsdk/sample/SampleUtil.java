package com.airyzone.beaconsdk.sample;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Environment;
import android.widget.Toast;

import com.airyzone.beaconsdk.sample.R;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * Created by lukeliu on 2017/5/28.
 */

public class SampleUtil {

    private static Toast mToast;

    public static String DOWNLOAD_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+ File.separator;
    public static String DFU_FILE = "collar_dev_104.zip";

    public static void showToast(Context context, String msg) {

        if ( mToast == null) {
            mToast = Toast. makeText(context, msg, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(msg);
        }
        mToast.show();
    }

    public static void showToast(Context context, int resId) {

        if ( mToast == null) {
            mToast = Toast. makeText(context, resId, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(resId);
        }
        mToast.show();
    }

    public static void setDialog(Context ctx, String title, String message){

        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm,
                        new AlertDialog.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // TODO Auto-generated method stub

                                dialog.cancel();
                            }
                        }).setCancelable( false).show();
    }

    public static void setDialog(Context ctx, String title, String message, final DialogButtonCallback callback){

        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm,
                        new AlertDialog.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // TODO Auto-generated method stub

                                dialog.cancel();

                                callback.onClick();
                            }
                        }).setCancelable( false).show();
    }

    public interface DialogButtonCallback {
        void onClick();
    }

    public static String getTime(String format){
        SimpleDateFormat nowdate = new java.text.SimpleDateFormat(format);
        nowdate.setTimeZone(TimeZone. getTimeZone("GMT+8"));
        String sdate = nowdate.format( new java.util.Date());
        return sdate;
    }

}
