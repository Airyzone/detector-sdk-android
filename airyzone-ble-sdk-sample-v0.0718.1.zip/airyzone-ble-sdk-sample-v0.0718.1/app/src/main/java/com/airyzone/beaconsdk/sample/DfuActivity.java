package com.airyzone.beaconsdk.sample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.airyzone.beaconsdk.Airyzone;
import com.airyzone.beaconsdk.util.BaseLogger;
import com.airyzone.beaconsdk.util.MBeaconDevice;

import java.io.File;

import no.nordicsemi.android.dfu.DfuProgressListener;
import no.nordicsemi.android.dfu.DfuProgressListenerAdapter;
import no.nordicsemi.android.dfu.DfuServiceListenerHelper;

import static com.airyzone.beaconsdk.sample.SampleUtil.DFU_FILE;
import static com.airyzone.beaconsdk.sample.SampleUtil.DOWNLOAD_PATH;

public class DfuActivity extends AppCompatActivity {

    private MBeaconDevice mBeaconDevice;

    private Airyzone airyzone;

    private TextView tvSpeed, tvAvgSpeed, tvPercent, tvFile;
    private ProgressBar pbDfu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dfu);

        final Intent intent = getIntent();
        mBeaconDevice = (MBeaconDevice) intent.getSerializableExtra("beacon");

        if (mBeaconDevice != null)
            getSupportActionBar().setTitle(mBeaconDevice.getDeviceName());

        airyzone = new Airyzone(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvSpeed = (TextView)findViewById(R.id.tv_speed);
        tvAvgSpeed = (TextView)findViewById(R.id.tv_avg_speed);
        tvPercent = (TextView)findViewById(R.id.tv_percent);
        tvFile = (TextView)findViewById(R.id.tv_file);

        pbDfu = (ProgressBar)findViewById(R.id.pb_dfu);

        final File otaFile = new File(DOWNLOAD_PATH, DFU_FILE);

        if (otaFile.exists())
            tvFile.setText(otaFile.getName());

        findViewById(R.id.btn_dfu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (otaFile.exists())
                    airyzone.performDFU(mBeaconDevice.getDeviceAddress(), otaFile.getPath(), performDFUCallback);
            }
        });

    }

    Airyzone.OnPerformDFUCallback performDFUCallback = new Airyzone.OnPerformDFUCallback() {
        @Override
        public void onDfuProcessStarting(String deviceAddress) {
            SampleUtil.showToast(DfuActivity.this, "Dfu Starting");
        }

        @Override
        public void onDfuCompleted(String deviceAddress) {
            SampleUtil.showToast(DfuActivity.this, "Dfu Completed");
            finish();
        }

        @Override
        public void onError(String deviceAddress, String message) {
            SampleUtil.showToast(DfuActivity.this, message);
        }

        @Override
        public void onProgressChanged(String deviceAddress, int percent, float speed, float avgSpeed) {
            pbDfu.setProgress(percent);
            tvPercent.setText(percent+"%");
            tvSpeed.setText(speed+"B/ms");
            tvAvgSpeed.setText(avgSpeed+"B/ms");
        }
    };

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }
}
