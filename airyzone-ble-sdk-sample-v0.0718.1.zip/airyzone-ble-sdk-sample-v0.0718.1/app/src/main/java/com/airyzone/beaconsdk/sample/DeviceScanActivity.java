package com.airyzone.beaconsdk.sample;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airyzone.beaconsdk.Airyzone;
import com.airyzone.beaconsdk.util.MBeaconDevice;

import java.util.ArrayList;
import java.util.List;

public class DeviceScanActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    private TextView mTvScan;
    private ProgressBar mPbScan;

    private static final int REQUEST_ENABLE_BT = 1;
    private BluetoothAdapter mBluetoothAdapter;

    private ListView mLvDevice;
    private BleDeviceAdapter mBleDeviceAdapter;
    private List<MBeaconDevice> mBeaconDeviceList;

    private Airyzone airyzone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_scan);

        findViewById(R.id.rl_scan).setOnClickListener(this);

        mTvScan = (TextView)findViewById(R.id.tv_scan);
        mPbScan = (ProgressBar) findViewById(R.id.pb_scan);

        mLvDevice = (ListView) findViewById(R.id.lv_device);
        mBeaconDeviceList = new ArrayList<>();
        mBleDeviceAdapter = new BleDeviceAdapter(this, 0, 0, mBeaconDeviceList);
        mLvDevice.setAdapter(mBleDeviceAdapter);
        mLvDevice.setOnItemClickListener(this);

        mBluetoothAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();

        airyzone = new Airyzone(this);
    }

    private void setScanText(boolean is){
        if (is){
            mTvScan.setText(R.string.menu_stop);
            mPbScan.setVisibility(View.VISIBLE);
        }else {
            mTvScan.setText(R.string.menu_scan);
            mPbScan.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Ensures Bluetooth is enabled on the device.  If Bluetooth is not currently enabled,
        // fire an intent to display a dialog asking the user to grant permission to enable it.
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

        airyzone.scanAiryzoneDevice(true, airyzoneScanCallback);
    }



    @Override
    protected void onPause() {
        super.onPause();
        airyzone.scanAiryzoneDevice(false, airyzoneScanCallback);
        mBeaconDeviceList.clear();
        mBleDeviceAdapter.notifyDataSetChanged();
    }

    private Airyzone.AiryzoneScanCallback airyzoneScanCallback = new Airyzone.AiryzoneScanCallback() {
        @Override
        public void onAiryzoneScan(MBeaconDevice mBleDevice) {
            if (mBleDevice!=null){

                boolean find=false;

                for (int i = 0; i < mBeaconDeviceList.size(); i++) {
                    if(mBeaconDeviceList.get(i).isSameDevice(mBleDevice)){
                        mBeaconDeviceList.remove(i);
                        mBeaconDeviceList.add(i, mBleDevice);
                        find=true;
                    }
                }

                if(!find){
                    mBeaconDeviceList.add(mBleDevice);
                }

                mBleDeviceAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void scanStatus(boolean isScanning) {
            setScanText(isScanning);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // User chose not to enable Bluetooth.
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            finish();
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.rl_scan:
                airyzone.scanAiryzoneDevice(airyzone.isScanning()?false:true, airyzoneScanCallback);
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent;
        if (mBeaconDeviceList.get(position).isDfuMode()){
            intent = new Intent(this, DfuActivity.class);
        }else {
            intent = new Intent(this, DeviceControlActivity.class);
        }
        intent.putExtra("beacon", mBeaconDeviceList.get(position));
        startActivity(intent);
    }

    private class BleDeviceAdapter extends ArrayAdapter<MBeaconDevice> {

        LayoutInflater inflater;

        public BleDeviceAdapter(Context context, int resource, int textViewResourceId,
                                List<MBeaconDevice> objects) {
            super(context, resource, textViewResourceId, objects);
            inflater = LayoutInflater. from(context);
        }

        @Override
        public View getView( int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.listitem_device,
                        null);
                holder = new ViewHolder();
                holder.deviceAddress = (TextView) convertView.findViewById(R.id.device_address);
                holder.deviceName = (TextView) convertView.findViewById(R.id.device_name);
                holder.deviceRssi = (TextView) convertView.findViewById(R.id.device_rssi);
                holder.deviceTime = (TextView) convertView.findViewById(R.id.device_time);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            MBeaconDevice device = getItem(position);

            final String deviceName = device.getDeviceName();
            if (deviceName != null && deviceName.length() > 0)
                holder.deviceName.setText(deviceName);
            else
                holder.deviceName.setText(R.string.unknown_device);

            holder.deviceAddress.setText(device.getDeviceAddress());
            holder.deviceRssi.setText(device.getRssi()+" dBm");
            holder.deviceTime.setText(device.getLastDiscoveryTime().toString());

            return convertView;
        }
    }

    static class ViewHolder {
        TextView deviceName, deviceAddress, deviceRssi, deviceTime;
    }
}
