package com.airyzone.beaconsdk.sample;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.airyzone.beaconsdk.Airyzone;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DeviceListActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private BleMappingAdapter mBleMappingAdapter;
    private List<JSONObject> mappingLists;
    private ListView mLvMapping;
    private String UserName;
    private RelativeLayout pbLoading;

    private Airyzone airyzone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);

        Intent intent = getIntent();
        if (intent==null || !intent.hasExtra("name"))
            finish();

        UserName = intent.getStringExtra("name");

        getSupportActionBar().setTitle(UserName);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        airyzone = new Airyzone(this);

        pbLoading = (RelativeLayout)findViewById(R.id.rl_progressBar);

        mappingLists = new ArrayList<>();
        mLvMapping = (ListView)findViewById(R.id.lv_mapping);
        mBleMappingAdapter = new BleMappingAdapter(this, 0, 0, mappingLists);
        mLvMapping.setAdapter(mBleMappingAdapter);
        mLvMapping.setOnItemClickListener(this);

        getMappingList();
    }

    private void getMappingList(){
        pbLoading.setVisibility(View.VISIBLE);
        airyzone.userBeaconList(UserName, new Airyzone.AiryzoneApiCallback() {
            @Override
            public void onJSONObjectResponse(JSONObject respObj) {
                try {
                    if (respObj.getString("sys_code").equals("200")){
                        mappingLists.clear();
                        JSONArray jArr = respObj.getJSONArray("datalist");
                        for (int i = 0; i < jArr.length(); i++) {
                            mappingLists.add(jArr.getJSONObject(i));
                        }
                        mBleMappingAdapter.notifyDataSetChanged();
                    }else {
                        SampleUtil.setDialog(DeviceListActivity.this, "BeaconList", respObj.toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                pbLoading.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final JSONObject jObj = mappingLists.get(position);
        try {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.user_beacon_unmapping)
                    .setMessage(jObj.getString("beacon_name") + "\n" + jObj.getString("beacon_id"))
                    .setPositiveButton(R.string.delete,
                            new AlertDialog.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    // TODO Auto-generated method stub

                                    try {
                                        airyzone.userBeaconUnmapping(UserName, jObj.getString("beacon_id"), new Airyzone.AiryzoneApiCallback() {
                                            @Override
                                            public void onJSONObjectResponse(JSONObject respObj) {
                                                try {
                                                    if (respObj.getString("sys_code").equals("200")){
                                                        SampleUtil.setDialog(DeviceListActivity.this, "BeaconUnmapping", respObj.toString(), new SampleUtil.DialogButtonCallback() {
                                                            @Override
                                                            public void onClick() {
                                                                getMappingList();
                                                            }
                                                        });
                                                    }else {
                                                        SampleUtil.setDialog(DeviceListActivity.this, "BeaconUnmapping:error", respObj.toString());
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                                pbLoading.setVisibility(View.GONE);
                                            }
                                        });
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            })
                    .setNeutralButton(R.string.cancel,
                            new AlertDialog.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    // TODO Auto-generated method stub
                                    dialog.cancel();
                                }
                            }).setCancelable( false).show();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private class BleMappingAdapter extends ArrayAdapter<JSONObject> {

        LayoutInflater inflater;

        public BleMappingAdapter(Context context, int resource, int textViewResourceId,
                                List<JSONObject> objects) {
            super(context, resource, textViewResourceId, objects);
            inflater = LayoutInflater. from(context);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.listitem_mapping,
                        null);
                holder = new ViewHolder();
                holder.beaconName = (TextView) convertView.findViewById(R.id.beacon_name);
                holder.beaconId = (TextView) convertView.findViewById(R.id.beacon_id);
                holder.beaconInfo = (ImageView) convertView.findViewById(R.id.iv_info);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            final JSONObject jObj = getItem(position);


            try {
                holder.beaconName.setText(jObj.getString("beacon_name"));
                holder.beaconId.setText(jObj.getString("beacon_id"));

                holder.beaconInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            SampleUtil.setDialog(DeviceListActivity.this, jObj.getString("beacon_id"), jObj.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return convertView;
        }
    }

    static class ViewHolder {
        TextView beaconName, beaconId;
        ImageView beaconInfo;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
