package com.airyzone.beaconsdk.sample;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;

import com.airyzone.beaconsdk.sample.R;

/**
 * Created by lukeliu on 2017/5/28.
 */

public class SampleUtil {

    private static Toast mToast;

    public static void showToast(Context context, String msg) {

        if ( mToast == null) {
            mToast = Toast. makeText(context, msg, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(msg);
        }
        mToast.show();
    }

    public static void showToast(Context context, int resId) {

        if ( mToast == null) {
            mToast = Toast. makeText(context, resId, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(resId);
        }
        mToast.show();
    }

    public static void setDialog(Context ctx, String title, String message){

        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm,
                        new AlertDialog.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // TODO Auto-generated method stub

                                dialog.cancel();
                            }
                        }).setCancelable( false).show();
    }

    public static void setDialog(Context ctx, String title, String message, final DialogButtonCallback callback){

        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm,
                        new AlertDialog.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                // TODO Auto-generated method stub

                                dialog.cancel();

                                callback.onClick();
                            }
                        }).setCancelable( false).show();
    }

    public interface DialogButtonCallback {
        void onClick();
    }

}
