package com.airyzone.beaconsdk.sample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.airyzone.beaconsdk.Airyzone;
import com.airyzone.beaconsdk.util.ABeaconDevice;

import org.json.JSONException;
import org.json.JSONObject;

public class DeviceControlActivity extends AppCompatActivity implements View.OnClickListener {

    private ABeaconDevice aBeaconDevice;

    private Airyzone airyzone;

    private RelativeLayout pbLoading;
    private EditText mEtUserId, mEtBeaconNickname, mEtLat, mEtLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_control);

        final Intent intent = getIntent();
        aBeaconDevice = (ABeaconDevice) intent.getSerializableExtra("beacon");

        if (aBeaconDevice != null)
            getSupportActionBar().setTitle(aBeaconDevice.getDeviceName());

        airyzone = new Airyzone(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        pbLoading = (RelativeLayout) findViewById(R.id.rl_progressBar);


        ((TextView) findViewById(R.id.device_address)).setText(aBeaconDevice.getDeviceAddress());

        findViewById(R.id.btn_opened).setOnClickListener(this);
        findViewById(R.id.btn_info).setOnClickListener(this);
        findViewById(R.id.btn_chk).setOnClickListener(this);

        findViewById(R.id.btn_register).setOnClickListener(this);
        findViewById(R.id.btn_binding).setOnClickListener(this);
        findViewById(R.id.btn_device_list).setOnClickListener(this);

        mEtUserId = (EditText) findViewById(R.id.et_userid);
        mEtBeaconNickname = (EditText) findViewById(R.id.et_nickname);

        ((TextView) findViewById(R.id.tv_device_mac)).setText(aBeaconDevice.getBeaconId());

        mEtLat = (EditText)findViewById(R.id.et_lat);
        mEtLng = (EditText)findViewById(R.id.et_lng);

        findViewById(R.id.btn_missing).setOnClickListener(this);
        findViewById(R.id.btn_missing_list).setOnClickListener(this);
        findViewById(R.id.btn_unmissing).setOnClickListener(this);
        findViewById(R.id.btn_collision).setOnClickListener(this);
        findViewById(R.id.btn_collision_log).setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home)
            onBackPressed();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_register:
                if (chkUserId()) {
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.registerUserId(mEtUserId.getText().toString(), airyzoneApiCallback);
                }
                break;
            case R.id.btn_binding:
                if (chkUserId() && chkNickname()){
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.userBeaconMapping(mEtUserId.getText().toString(), aBeaconDevice.getBeaconId(), mEtBeaconNickname.getText().toString(), airyzoneApiCallback);
                }
                break;
            case R.id.btn_device_list:
                if (chkUserId())
                    startActivity(new Intent(DeviceControlActivity.this, DeviceListActivity.class).putExtra("name", mEtUserId.getText().toString()));
                break;

            case R.id.btn_info:
                pbLoading.setVisibility(View.VISIBLE);
                airyzone.beaconInfo(aBeaconDevice.getBeaconId(), airyzoneApiCallback);
                break;
            case R.id.btn_chk:
                pbLoading.setVisibility(View.VISIBLE);
                airyzone.beaconChk(aBeaconDevice.getBeaconId(), airyzoneApiCallback);
                break;

            case R.id.btn_opened:
                pbLoading.setVisibility(View.VISIBLE);
                airyzone.openedDevice(aBeaconDevice, openedCallback);
                break;

            case R.id.btn_missing:
                if (chkUserId()){
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.setBeaconMissing(mEtUserId.getText().toString(), aBeaconDevice.getBeaconId(), airyzoneApiCallback);
                }
                break;

            case R.id.btn_missing_list:
                if (chkUserId()){
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.getBeaconMissingList(mEtUserId.getText().toString(), airyzoneApiCallback);
                }
                break;

            case R.id.btn_unmissing:
                if (chkUserId()){
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.setBeaconUnmissing(mEtUserId.getText().toString(), aBeaconDevice.getBeaconId(), airyzoneApiCallback);
                }
                break;

            case R.id.btn_collision:
                if (chkUserId() && chkLatLng()){
                    pbLoading.setVisibility(View.VISIBLE);
                    airyzone.setBeaconCollision(mEtUserId.getText().toString(), aBeaconDevice.getBeaconId(), mEtLat.getText().toString(), mEtLng.getText().toString(), airyzoneApiCallback);
                }
                break;

            case R.id.btn_collision_log:
                pbLoading.setVisibility(View.VISIBLE);
                airyzone.getBeaconCollisionLog(aBeaconDevice.getBeaconId(), airyzoneApiCallback);
                break;
        }
    }

    Airyzone.OpenedCallback openedCallback = new Airyzone.OpenedCallback() {
        @Override
        public void onOpenedResponse(JSONObject respObj) {
            pbLoading.setVisibility(View.GONE);
            SampleUtil.setDialog(DeviceControlActivity.this, "onOpenedResponse", respObj.toString());
        }
    };

    Airyzone.AiryzoneApiCallback airyzoneApiCallback = new Airyzone.AiryzoneApiCallback() {
        @Override
        public void onJSONObjectResponse(JSONObject respObj) {
            SampleUtil.setDialog(DeviceControlActivity.this, "AiryzoneResponse", respObj.toString());
            pbLoading.setVisibility(View.GONE);
        }
    };

    private boolean chkUserId(){
        if (mEtUserId.getText().length() > 0){
            return true;
        }
        SampleUtil.showToast(this, R.string.hint_user_id);
        return false;
    }

    private boolean chkNickname(){
        if (mEtBeaconNickname.getText().length() > 0){
            return true;
        }
        SampleUtil.showToast(this, R.string.hint_nickname);
        return false;
    }

    private boolean chkLatLng(){

        if (mEtLat.getText().length() > 0 && mEtLng.getText().length() > 0){
            return true;
        }
        SampleUtil.showToast(this, R.string.enter_latlng);
        return false;
    }

}
